#include <GSM3MobileSMSProvider.h>

GSM3MobileSMSProvider* theGSM3SMSProvider;
